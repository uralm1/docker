authplaincas
===========

CAS authentication for dokuwiki without LDAP but using cas attributes

clone this repository as "authplaincas" in the plugin directory
