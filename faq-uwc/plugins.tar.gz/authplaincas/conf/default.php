<?php
$conf['name'] = 'CAS Login';
$conf['logourl'] = '';
// $conf['localname'] = 'Local Login';
// $conf['jshidelocal'] = 1;

$conf['server'] = '';
$conf['rootcas'] = '';
$conf['port'] = '';
$conf['samlValidate'] = 0;

$conf['handlelogoutrequest'] = 0;
$conf['handlelogoutrequestTrustedHosts'] = '';

$conf['autologin'] = 0;

$conf['localusers'] = 0;
$conf['minimalgroups'] = '';

$conf['force_redirect'] = 0;
