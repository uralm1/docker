<?php
$meta['name'] = array('string');
$meta['logourl'] = array('string');
// $meta['localname'] = array('string');
// $meta['jshidelocal'] = array('onoff');

$meta['server'] = array('string');
$meta['rootcas'] = array('string');
$meta['port'] = array('string');


$meta['handlelogoutrequest'] = array('onoff');
$meta['handlelogoutrequestTrustedHosts'] = array('string');

$meta['autologin'] = array('onoff');

// $meta['localusers'] = array('onoff');
$meta['minimalgroups'] = array('string');

$meta['force_redirect'] = array('onoff');
