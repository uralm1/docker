<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Anika Henke <anika@selfthinker.org>
 */
$lang['userexists']     = 'Der Benutzername existiert leider schon.';
$lang['usernotexists']  = 'Dieser Benutzer existiert nicht.';
$lang['writefail']      = 'Kann Benutzerdaten nicht ändern. Bitte informieren Sie den Wiki-Administratoren';