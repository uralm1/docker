<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['__background_site__']   = '(내용 상자 뒤의) 매우 배경 색';
$lang['__link__']              = '일반 링크 색';
$lang['__existing__']          = '문서가 존재하는 링크의 색';
$lang['__missing__']           = '문서가 존재하지 않는 링크의 색';
$lang['__site_width__']        = '전체 사이트의 너비 (아무 길이 단위나 될 수 있음: %, px, em, ...)';
$lang['__sidebar_width__']     = '사이드바가 있다면, 그것의 너비 (아무 길이 단위나 될 수 있음: %, px, em, ...)';
$lang['__tablet_width__']      = '사이트를 태블릿 모드로 전환할 화면 너비';
$lang['__phone_width__']       = '사이트를 폰 모드로 전환할 화면 너비';
