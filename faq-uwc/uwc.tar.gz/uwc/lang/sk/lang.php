<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Martin Michalek <michalek.dev@gmail.com>
 */
$lang['__background_site__']   = 'Farba základného pozadia (za oknom s obsahom)';
$lang['__link__']              = 'Všeobecná farba odkazu';
$lang['__existing__']          = 'Farba odkazov na existujúce stránky';
$lang['__missing__']           = 'Farba odkazov na neexistujúce stránky';
