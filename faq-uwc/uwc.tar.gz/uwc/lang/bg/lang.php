<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Kiril <neohidra@gmail.com>
 */
$lang['__background_site__']   = 'Цвят за фона, под съдъжанието';
$lang['__link__']              = 'Стандартен цвят за препратка';
$lang['__existing__']          = 'Цвят за препратка към съществуващи станици';
$lang['__missing__']           = 'Цвят за препратка към несъществуващи станици';
$lang['__site_width__']        = 'Ширина на целия сайт (може да бъде всяка мерна единица:%, px, em, ...)';
$lang['__sidebar_width__']     = 'Ширина на страничната лента (може да бъде всяка мерна единица:%, px, em, ...)';
