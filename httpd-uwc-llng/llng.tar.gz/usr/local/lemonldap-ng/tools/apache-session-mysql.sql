CREATE TABLE sessions (
		id char(32) not null primary key,
		a_session text
		);

